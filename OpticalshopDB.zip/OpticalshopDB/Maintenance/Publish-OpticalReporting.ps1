[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)] [string] $OpsDatabase,
    [Parameter(Mandatory)] [string] $WorkforceDatabase,
    [Parameter(Mandatory)] [string] $ReferenceDatabase,
    [Parameter(Mandatory)] [string] $ReportingDatabase,
    [string] $PublishedBy = $env:USERNAME
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
foreach ($db in @($OpsDatabase,$WorkforceDatabase,$ReferenceDatabase,$ReportingDatabase)) {
    if (-not (Test-Path -LiteralPath $db -PathType Leaf)) { throw "Database not found: $db" }
}

function Open-Connection([string] $path) {
    $connection = New-Object System.Data.OleDb.OleDbConnection "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=$path;Mode=Share Deny None;"
    $connection.Open(); return $connection
}
function Read-Rows($connection, [string] $sql) {
    $cmd = $connection.CreateCommand(); $cmd.CommandText = $sql
    $reader = $cmd.ExecuteReader(); $rows = @()
    while ($reader.Read()) {
        $row = [ordered]@{}
        for ($i=0; $i -lt $reader.FieldCount; $i++) { $row[$reader.GetName($i)] = if ($reader.IsDBNull($i)) { $null } else { $reader.GetValue($i) } }
        $rows += [pscustomobject]$row
    }
    $reader.Close(); return $rows
}
function Add-Row($connection, [string] $sql, [object[]] $values) {
    $cmd = $connection.CreateCommand(); $cmd.CommandText = $sql
    if ($null -ne $script:publishTransaction) { $cmd.Transaction = $script:publishTransaction }
    foreach ($value in $values) {
        $type = if ($null -eq $value) { [System.Data.OleDb.OleDbType]::Variant }
            elseif ($value -is [datetime]) { [System.Data.OleDb.OleDbType]::Date }
            elseif ($value -is [double] -or $value -is [single] -or $value -is [decimal]) { [System.Data.OleDb.OleDbType]::Double }
            elseif ($value -is [int] -or $value -is [long]) { [System.Data.OleDb.OleDbType]::Integer }
            else { [System.Data.OleDb.OleDbType]::VarWChar }
        $parameter = $cmd.Parameters.Add('@p', $type)
        $parameter.Value = if ($null -eq $value) { [DBNull]::Value } else { $value }
    }
    [void]$cmd.ExecuteNonQuery()
}

$ops = Open-Connection $OpsDatabase
$workforce = Open-Connection $WorkforceDatabase
$reference = Open-Connection $ReferenceDatabase
$reporting = Open-Connection $ReportingDatabase
try {
    # Only aggregates are selected. Patient names, identifiers, order numbers, and note text never leave the restricted databases.
    $jobs = Read-Rows $ops 'SELECT [OrderDate], [TrackingDate], [LocationCode] FROM [tblJobTracking] WHERE [OrderDate] IS NOT NULL'
    $exceptions = Read-Rows $workforce 'SELECT [NotificationDateFromLab], [LocationName], [DateCompleted] FROM [Exceptions] WHERE [NotificationDateFromLab] IS NOT NULL'
    $remakes = Read-Rows $workforce 'SELECT [Remake Date], [Original Location] FROM [Remakes] WHERE [Remake Date] IS NOT NULL'
    $workload = Read-Rows $workforce 'SELECT [Date], [ClinicName], [ActivityCount] FROM [EmployeeWorkload] WHERE [Date] IS NOT NULL'
    $clinics = Read-Rows $reference 'SELECT [ClinicName], [LocationName] FROM [Clinics]'
    $clinicLocations = @{}
    foreach ($clinic in $clinics) { $clinicLocations[[string]$clinic.ClinicName] = $clinic.LocationName }
    foreach ($row in $workload) { $row | Add-Member -NotePropertyName LocationName -NotePropertyValue $clinicLocations[[string]$row.ClinicName] }

    if ($PSCmdlet.ShouldProcess($ReportingDatabase, 'Replace aggregate reporting snapshot')) {
        $tx = $reporting.BeginTransaction()
        try {
            foreach ($table in @('rptOpsTurnaround','rptQualityMetrics','rptWorkforceMetrics')) {
                $cmd=$reporting.CreateCommand(); $cmd.Transaction=$tx; $cmd.CommandText="DELETE FROM [$table]"; [void]$cmd.ExecuteNonQuery()
            }
            $script:publishTransaction = $tx
            $jobGroups = $jobs | Group-Object { '{0:yyyy-MM-01}|{1}' -f ([datetime]$_.OrderDate), $(if ($null -eq $_.LocationCode) { '' } else { $_.LocationCode }) }
            foreach ($g in $jobGroups) {
                $sample=$g.Group[0]; $completed=@($g.Group | Where-Object {$_.TrackingDate}); $weeks=@($completed | ForEach-Object { (([datetime]$_.TrackingDate - [datetime]$_.OrderDate).TotalDays / 7.0) })
                $avg=if($weeks.Count){($weeks | Measure-Object -Average).Average}else{$null}
                $p95=if($weeks.Count){($weeks | Sort-Object)[[math]::Min($weeks.Count-1,[math]::Ceiling($weeks.Count*.95)-1)]}else{$null}
                Add-Row $reporting 'INSERT INTO rptOpsTurnaround (MetricDate,LocationCode,CompletedJobs,AverageWeeks,Percentile95Weeks,OpenJobs) VALUES (?,?,?,?,?,?)' @(([datetime]$sample.OrderDate).Date.AddDays(1-([datetime]$sample.OrderDate).Day),$sample.LocationCode,$completed.Count,$avg,$p95,($g.Count-$completed.Count))
            }
            $qualityGroups = $exceptions | Group-Object { '{0:yyyy-MM-01}|{1}' -f ([datetime]$_.NotificationDateFromLab), $(if ($null -eq $_.LocationName) { '' } else { $_.LocationName }) }
            foreach ($g in $qualityGroups) { $sample=$g.Group[0]; Add-Row $reporting 'INSERT INTO rptQualityMetrics (MetricMonth,LocationName,TotalExceptions,EmployeeCaused,Remakes,OpenExceptions) VALUES (?,?,?,?,?,?)' @(([datetime]$sample.NotificationDateFromLab).Date.AddDays(1-([datetime]$sample.NotificationDateFromLab).Day),$sample.LocationName,$g.Count,$null,$null,@($g.Group|Where-Object {-not $_.DateCompleted}).Count) }
            $workGroups = $workload | Group-Object { '{0:yyyy-MM-01}|{1}' -f ([datetime]$_.Date), $(if ($null -eq $_.LocationName) { '' } else { $_.LocationName }) }
            foreach ($g in $workGroups) { $sample=$g.Group[0]; Add-Row $reporting 'INSERT INTO rptWorkforceMetrics (MetricMonth,LocationName,TotalActivity,StaffingLevel,KudosCount,AwardsCount) VALUES (?,?,?,?,?,?)' @(([datetime]$sample.Date).Date.AddDays(1-([datetime]$sample.Date).Day),$sample.LocationName,(($g.Group|Measure-Object ActivityCount -Sum).Sum),$null,$null,$null) }
            Add-Row $reporting 'INSERT INTO rptPublishLog (PublishedAt,PublishedBy,Status,Detail) VALUES (?,?,?,?)' @((Get-Date),$PublishedBy,'Complete','Aggregate snapshot published by Publish-OpticalReporting.ps1')
            $tx.Commit()
        } catch { $tx.Rollback(); throw }
        finally { $script:publishTransaction = $null }
    }
} finally { foreach($cn in @($ops,$workforce,$reference,$reporting)){ if($null -ne $cn){$cn.Close()} } }
