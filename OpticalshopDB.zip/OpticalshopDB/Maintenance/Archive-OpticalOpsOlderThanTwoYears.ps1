[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)] [string] $OpsDatabase,
    [Parameter(Mandatory)] [string] $WorkforceQualityDatabase,
    [Parameter(Mandatory)] [string] $ArchiveFolder,
    [switch] $IncludeSafetyAndStaffingHistory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Master/reference lists (Employees, StaffList, Locations, Clinics, FrameList,
# roles, configuration, and fiscal periods) never appear here and stay active.
$archiveRules = @(
    @{ Database = 'Ops'; Table = 'tblJobTracking'; DateField = 'OrderDate'; RetentionYears = 1 },
    @{ Database = 'Ops'; Table = 'ConsultTracking'; DateField = 'Created Date'; RetentionYears = 1 },
    @{ Database = 'Ops'; Table = 'CTM'; DateField = 'Created Date'; RetentionYears = 1 },
    @{ Database = 'Workforce'; Table = 'Optician Hours Worked'; DateField = 'PPEnd Date'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Kudos'; DateField = 'Date of Kudos'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Awards'; DateField = 'Award Date'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Complaints'; DateField = 'DateOfComplaint'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'ComplimentsFromVeterans'; DateField = 'DateOfCompliment'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Veteran Commendations'; DateField = 'Date of Comendation'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'EmployeeWorkload'; DateField = 'Date'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'EncountersCount'; DateField = 'EncounterDate'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Exceptions'; DateField = 'NotificationDateFromLab'; RetentionYears = 2 },
    @{ Database = 'Workforce'; Table = 'Remakes'; DateField = 'Remake Date'; RetentionYears = 2 }
)
if ($IncludeSafetyAndStaffingHistory) {
    $archiveRules += @(
        @{ Database = 'Workforce'; Table = 'Location Staffing'; DateField = 'RecordDate'; RetentionYears = 2 },
        @{ Database = 'Workforce'; Table = 'HRO'; DateField = 'HuddleDate'; RetentionYears = 2 },
        @{ Database = 'Workforce'; Table = 'HROMeetingReport'; DateField = 'DateColumn'; RetentionYears = 2 }
    )
}

function Assert-Closed([string] $database) {
    $lock = [System.IO.Path]::ChangeExtension($database, '.laccdb')
    if (Test-Path -LiteralPath $lock) { throw "Access appears open. Close it before archiving: $database" }
}
function Quote([string] $name) { '[' + $name.Replace(']', ']]') + ']' }
function Open-Dao([string] $path, [bool] $readOnly = $false) {
    $engine = New-Object -ComObject DAO.DBEngine.120
    @{ Engine = $engine; Database = $engine.OpenDatabase($path, $false, $readOnly) }
}
foreach ($db in @($OpsDatabase,$WorkforceQualityDatabase)) {
    if (-not (Test-Path -LiteralPath $db -PathType Leaf)) { throw "Database not found: $db" }
    Assert-Closed $db
}
if (-not (Test-Path -LiteralPath $ArchiveFolder)) { New-Item -ItemType Directory -Path $ArchiveFolder -Force | Out-Null }

# A pre-flight report is intentionally the only enabled behavior.  It prevents
# unattended destructive archiving until VA retention rules and per-table date
# semantics are validated against representative data.
$connections = @{ Ops = Open-Dao $OpsDatabase $true; Workforce = Open-Dao $WorkforceQualityDatabase $true }
try {
    foreach ($rule in $archiveRules) {
        $cutoffDate = (Get-Date).Date.AddYears(-[int]$rule.RetentionYears)
        $cutoffLiteral = '#' + $cutoffDate.ToString('yyyy-MM-dd') + '#'
        $sql = "SELECT Count(*) AS N FROM $(Quote $($rule.Table)) WHERE $(Quote $($rule.DateField)) < $cutoffLiteral"
        $rs = $connections[$rule.Database].Database.OpenRecordset($sql)
        [pscustomobject]@{ Database = $rule.Database; Table = $rule.Table; DateField = $rule.DateField; RetentionYears = $rule.RetentionYears; RecordsEligibleForArchive = [int]$rs.Fields('N').Value; Cutoff = $cutoffDate.ToString('yyyy-MM-dd') }
        $rs.Close()
    }
} finally { foreach ($connection in $connections.Values) { $connection.Database.Close() } }

Write-Warning 'No records were moved. This pre-flight confirms the retention policy before the move-and-compact stage is enabled.'
