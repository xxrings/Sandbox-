[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)] [string[]] $BackEndPaths,
    [Parameter(Mandatory)] [string] $BackupRoot,
    [ValidateRange(1,3650)] [int] $RetentionDays = 14,
    [switch] $AllowLocalForValidation
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not $AllowLocalForValidation -and -not $BackupRoot.StartsWith('\\')) {
    throw 'BackupRoot must be a VA-network UNC path in production.'
}
foreach ($db in $BackEndPaths) {
    if (-not (Test-Path -LiteralPath $db -PathType Leaf)) { throw "Back end not found: $db" }
    $lock = [System.IO.Path]::ChangeExtension($db, '.laccdb')
    if (Test-Path -LiteralPath $lock) { throw "Back end appears to be open; backup aborted: $db" }
}

$stamp = Get-Date -Format 'yyyy-MM-dd_HHmmss'
$destination = Join-Path $BackupRoot $stamp
if ($PSCmdlet.ShouldProcess($destination, 'Create dated Access backup')) {
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($db in $BackEndPaths) {
        Copy-Item -LiteralPath $db -Destination (Join-Path $destination ([System.IO.Path]::GetFileName($db))) -ErrorAction Stop
    }
}

$cutoff = (Get-Date).AddDays(-$RetentionDays)
$resolvedRoot = (Resolve-Path -LiteralPath $BackupRoot).Path.TrimEnd('\')
Get-ChildItem -LiteralPath $resolvedRoot -Directory | Where-Object {
    $_.Name -match '^\d{4}-\d{2}-\d{2}_\d{6}$' -and $_.LastWriteTime -lt $cutoff
} | ForEach-Object {
    $candidate = $_.FullName
    if (-not $candidate.StartsWith($resolvedRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Unsafe backup-cleanup target: $candidate"
    }
    if ($PSCmdlet.ShouldProcess($candidate, 'Remove expired dated backup')) {
        Remove-Item -LiteralPath $candidate -Recurse -Force
    }
}

Write-Output "Backup created: $destination"
