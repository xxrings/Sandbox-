$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$release=Join-Path $root 'DailySnapshotDeliverable_v19'
New-Item -ItemType Directory -Path $release -Force | Out-Null
$output=Join-Path $release 'OpticalAdmin_FE_DailySnapshot_v19_READY.accdb'
if(Test-Path -LiteralPath $output){throw 'v19 output already exists. Preserve it before rebuilding.'}
$working=Join-Path $release 'v19_build.accdb'
if(Test-Path -LiteralPath $working){throw 'Build copy already exists.'}
Copy-Item -LiteralPath (Join-Path $root 'DailySnapshotDeliverable_v18\OpticalAdmin_FE_DailySnapshot_v18_READY.accdb') -Destination $working
$a=$null
try {
    $a=New-Object -ComObject Access.Application
    $a.AutomationSecurity=1
    $a.OpenCurrentDatabase($working)
    $a.DoCmd.DeleteObject(5,'modDailySnapshotExtensions')
    $a.LoadFromText(5,'modDailySnapshotExtensions',(Join-Path $root 'modDailySnapshotExtensions_v19.txt'))
    $a.RunCommand(125)
    $a.CloseCurrentDatabase()
    $a.OpenCurrentDatabase($working)
    if(-not $a.Run('DS_SmokeTest')){throw 'Extension smoke check failed'}
    if(-not $a.Run('JT_SmokeTest')){throw 'Job Tracking smoke check failed'}
    $db=$a.CurrentDb()
    # Clear only local sample staging/history in the new release copy.
    foreach($table in @($db.TableDefs)) {
        if([string]::IsNullOrEmpty($table.Connect) -and ($table.Name -like 'stgDaily*' -or $table.Name -like 'tmpDailyLoad*' -or $table.Name -in @('ImportIssue','ImportRun','SnapshotDomainIssue','SnapshotDomainRun','stg_ImportLog'))) {
            $db.Execute('DELETE FROM ['+$table.Name+']',128)
        }
    }
    $a.DoCmd.OpenForm('frmDailyJobTracking',1)
    $form=$a.Forms.Item('frmDailyJobTracking')
    $form.Caption='Daily Snapshot Import - v19'
    $form.Controls.Item('lblSnapshotTitle').Caption='Daily Snapshot Import - v19'
    $label=$form.Controls.Item('lblSnapshotInstruction')
    $label.Caption='Import the complete daily workbook, then commit validated data.'
    $label.Height=600
    $form.Width=9600
    $a.DoCmd.Close(2,'frmDailyJobTracking',1)
    $a.CloseCurrentDatabase()
    $a.Quit()
    $a=$null; $db=$null; $table=$null; $form=$null; $label=$null
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    $a=New-Object -ComObject Access.Application
    $a.AutomationSecurity=1
    $a.CompactRepair($working,$output,$false) | Out-Null
    $a.OpenCurrentDatabase($output)
    if(-not $a.Run('DS_SmokeTest')){throw 'Packaged extension smoke check failed'}
    $db=$a.CurrentDb()
    if($db.OpenRecordset('SELECT Count(*) FROM ImportRun').Fields.Item(0).Value -ne 0){throw 'Sample import history remains'}
    $a.SaveAsText(5,'modDailySnapshotExtensions',(Join-Path $release 'verified_module_export.txt'))
    $a.CloseCurrentDatabase()
    Remove-Item -LiteralPath $working
    Write-Output $output
} finally {if($null -ne $a){try{$a.CloseCurrentDatabase()}catch{};try{$a.Quit()}catch{}}}
