DAILY SNAPSHOT v19 - AUTOMATIC REPORT FOOTER HANDLING
===================================================

USE THIS FILE
OpticalAdmin_FE_DailySnapshot_v19_READY.accdb
The form title must say: Daily Snapshot Import - v19.

WHAT CHANGED
WorkLoad's trailing totals row and UnsignedNotes' trailing notation no longer
need to be deleted from the Excel export. Detection follows the end of the
imported list, so it does not depend on rows 97 or 4360. Excel is not modified.

At most one matching footer is excluded per sheet. Blank and whitespace-only
tail rows do not prevent detection and are not staged as records.

Recognized shapes:
- WorkLoad: the last nonblank row has a numeric Activity Count and no activity
  dimensions. Date and StaffName are blank or contain Total, Totals, Grand Total,
  or Grand Totals. Other source columns must be blank.
- UnsignedNotes: the last nonblank row contains the notation in Service, with
  Author, Age of Note, Patient & Entry Date, Note Title, and other columns blank.

Incomplete real rows with dates, note identity, age values, activity dimensions,
or other populated fields still undergo normal validation. A footer-like row
in the middle of a list is not excluded. If the source changes its layout, the
importer may report validation errors rather than skip an unknown record.

The successful import message says, for example:
  Validated (95 rows; 1 footer row excluded)
For the exact workbook shown in your screenshots, expected accepted counts are
95 WorkLoad records and 4,357 UnsignedNotes records if these are the only issues.
Counts will naturally change with subsequent exports.

Import History retains the original nonblank SourceRows count including the
footer; AcceptedRows excludes it. SnapshotDomainIssue records the exclusion as
Info rather than Error. This audit entry contains no footer text or patient data.

INSTALL AND RUN
1. Close Access. Keep your current front end as a backup.
2. Extract the ZIP. Copy the v19 ACCDB beside your current front end in its
   approved working folder. Open the v19 file directly, not an old shortcut.
3. Confirm the title says Daily Snapshot Import - v19.
4. Save and close today's original complete Excel export. Keep the totals row
   and ending notation. No Note ID column needs to be added.
5. Select Import and Validate Daily Workbook. Select the original export.
6. Check both domain results and accepted counts. If they validate, select
   Commit Validated Data, review the ready domains, and confirm.
7. Check the final commit result and Import History.

If the notes list is genuinely empty (headers and optional footer only), the
existing zero-row commit warning requires confirmation because all previously
listed notes will become no longer listed. A totals-only WorkLoad sheet still
fails because it contains no activity records.

BACK-END DATA AND LINKS
This package contains a front end only. It does not replace your back ends.
It starts with empty local staging/history. Your previous front end retains its
local import history. Note IDs and note history live in the Operations back end.

The linked destinations are preserved from the supplied v18/v17 files:
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Ops\OpticalOps_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\WorkforceQuality\WorkforceQuality_BE.accdb
The other Reference and Operations links are also preserved. If your deployed
front end was relinked to different locations, use External Data > Linked Table
Manager to select those same existing back ends. Do not rename folders to match
the spellings above.

RETAINED V18 BEHAVIOR
- Error 3265 metadata fix and complete error descriptions.
- Database-generated note IDs. Matching uses Patient & Entry Date, Author,
  Note Title, and Service; changing ages do not create new notes.
- Ambiguous identities stop validation instead of being merged.
- Missing notes become no longer listed; this is not proof they were signed.
- Matching notes that reappear reuse their IDs and retain earlier history.
- Same-day snapshots replace that day's observations without duplication.
- Failed imports cannot commit old stages for those domains.
- Note commits use a back-end backup and transaction; a failed write rolls back.

Matching depends on the identifying fields remaining stable. If one changes,
the import treats it as a new note. Use today's complete original export and
import/commit on the same day. A scrubbed file with blank identities cannot be
used to validate actual note tracking. No patient-identifying file is needed
for troubleshooting here; send only the error messages and non-identifying
footer labels if anything still fails.

TESTING
Native Access regression results are included in this package. Tests use
disposable local back ends and synthetic notes. The real VA-network back ends
and original identifying data were not accessed. Job Tracking code is unchanged.
