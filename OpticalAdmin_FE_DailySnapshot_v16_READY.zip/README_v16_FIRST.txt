DAILY SNAPSHOT v16 — WORKLOAD DATE-HEADER COMPATIBILITY
========================================================

Use OpticalAdmin_FE_DailySnapshot_v16_READY.accdb.

The Daily Snapshot form has only three actions:
  • Import and Validate Daily Workbook
  • Commit Validated Data
  • Import History

The WorkLoad importer now accepts the standard Date header plus common source
variations: Work Date, WorkDate, Workload Date, Activity Date, and Report Date.
It also handles Access's safe rename of a duplicate Date header to Date1. If no
recognized date field is present, Import History now reports all imported column
names so the source mapping can be corrected precisely.

UnsignedNotes remains intentionally blocked until the export includes an exact
Note ID header with a permanent, unique value on each nonblank source row.

WorkLoad and Unsigned Notes commits still refresh their backend aggregate tables
for the separate reporting front end. This Admin snapshot front end contains no
report, queue, or aggregate-query UI.
