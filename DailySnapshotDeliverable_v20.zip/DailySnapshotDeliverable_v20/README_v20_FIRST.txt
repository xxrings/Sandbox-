DAILY SNAPSHOT v20 - WORKLOAD REPORT REFRESH
==========================================

YOUR LAST COMMIT SUCCEEDED
The screenshot showed Job Tracking committed, 95 new WorkLoad rows committed,
and 4,357 new unsigned notes committed with their reporting data refreshed.
Only the WorkLoad aggregate reporting refresh failed. Do not re-import that
workbook to repair the reports.

RECOVER THE WORKLOAD REPORTS
1. Close Access and retain your current v19 front end as a backup.
2. Extract this ZIP. Put OpticalAdmin_FE_DailySnapshot_v20_READY.accdb beside
   your current front end in the approved working folder.
3. Open v20 directly. Verify the form title: Daily Snapshot Import - v20.
4. Click Refresh WorkLoad Reports. No workbook selection or data commit is
   needed. The button rebuilds daily and monthly WorkLoad report tables from
   already-saved backend records.
5. Expect: WorkLoad daily and monthly reporting data refreshed successfully.
   Import History records this as a separate Workload reports operation.
6. Use v20 for future daily imports and commits as usual. Leave the Excel totals
   row and unsigned-notes ending notation in place; v19 footer handling remains.

WHAT CHANGED
The supplied deployed WorkforceQuality backend uses EmployeeWorkload.WorkDate,
ClinicCode, and LocationCode. The earlier refresh query expected Date and
ClinicName. v20 detects either supported schema before rebuilding reports.
Normalized clinic/location codes are retained as codes in the existing report
ClinicName/LocationName fields; it does not invent a name-to-code lookup.
Daily groups now use the calendar day if source dates include a time.

Both daily and monthly report tables rebuild in one transaction. A write failure
rolls back the report replacements. Missing fields and invalid historical dates
produce specific errors before reports are cleared. Errors retain their number
and description in the popup, Import History, and SnapshotDomainIssue.

The Refresh WorkLoad Reports action changes only derived WorkLoad reports and
local refresh logs (and creates required schema if absent). It does not import
Excel, commit Job Tracking, update note status, or change saved workload rows.
Its separate history row has zero source/accepted import counts because it is
a reporting operation. The original v19 history stays in your old front end.

IF REFRESH STILL FAILS
Copy the complete error number and text. Also open SnapshotDomainIssue and copy
the latest Workload Warning beginning Reporting refresh failed. Patient data
and the full source workbook are not needed for this step.

Invalid historical dates must be corrected in the source records; the importer
does not silently discard that workload. A missing path or locked backend may
also require correcting the linked location or closing another Access session.

BACK-END LINKS
v20 retains the links supplied with v19, including:
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\WorkforceQuality\WorkforceQuality_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Ops\OpticalOps_BE.accdb
If your deployed front end was relinked elsewhere, use External Data > Linked
Table Manager to point v20 to those same existing back ends. Do not rename your
folders to match these spellings. This ZIP contains no replacement back ends.

NOTE TRACKING AND FOOTERS
Existing database-generated note IDs remain in the Operations backend. Matching
still uses Patient & Entry Date, Author, Note Title, and Service, excluding age.
Missing notes mean no longer listed, not confirmed signed. Blank/ambiguous real
records remain validation errors. Only the confirmed terminal footer shapes are
excluded, with informational audit entries. Source workbooks are not modified.

VERIFICATION
The included native Access tests cover both historical workload layouts with
nonempty data, daily/monthly totals, repeat refreshes, invalid-date/schema errors,
and rollback of both report tables after an injected write failure. Tests use
disposable local databases. Real VA-network databases were not modified here.
