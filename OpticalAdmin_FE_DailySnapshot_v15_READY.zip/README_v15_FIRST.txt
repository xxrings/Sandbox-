DAILY SNAPSHOT v15 — SIMPLE THREE-BUTTON WORKFLOW
==================================================

Open OpticalAdmin_FE_DailySnapshot_v15_READY.accdb and use the Daily Snapshot
Import form.

THE ONLY FORM ACTIONS
---------------------
1. Import and Validate Daily Workbook
   Select the workbook once. Job Tracking, WorkLoad, and Unsigned Notes are
   imported and validated independently. A failed domain leaves its previous
   validated stage unchanged and does not affect the others.

2. Commit Validated Data
   One confirmation shows which domains are ready. Job Tracking, WorkLoad, and
   Unsigned Notes then commit in sequence. A failure in one is logged but does
   not stop another ready domain. Repeating this action is safe and also retries
   a prior automatic aggregate-refresh failure.

3. Import History
   Opens the combined Job Tracking and extension import history. Detailed
   validation issues remain in SnapshotDomainIssue for troubleshooting.

There are no report, queue, staging-review, Clear Staging, or refresh buttons
on this Admin snapshot form. The staging tables remain available through the
Navigation Pane for authorized technical review.

REPORTING
---------
This front end does not create or expose reporting queries, reports, or the
restricted unsigned-notes queue. The commit process still refreshes the backend
aggregate tables so the separate reporting front end can link to them:
  WorkforceQuality_BE: WorkloadActivity, rptWorkloadActivityDaily,
  rptWorkloadActivityMonthly
  OpticalOps_BE: UnsignedNote, UnsignedNoteObservation, rptUnsignedNoteDaily

Patient & Entry Date remains only in OpticalOps_BE.UnsignedNote. It is not in
the aggregate reporting tables.

REQUIRED UNSIGNED NOTES COLUMN
------------------------------
UnsignedNotes must contain a permanent, unique Note ID column. The supplied
scrubbed DailyTracking.xlsm does not include it, so that tab intentionally fails
validation until the actual export includes the exact Note ID header.

BACKUPS
-------
Every WorkLoad commit creates a dated WorkforceQuality back-end backup before
writing. Every Unsigned Notes commit creates a dated Operations back-end backup
before writing.
