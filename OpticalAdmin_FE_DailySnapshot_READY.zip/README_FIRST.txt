OPTICAL ADMIN DAILY SNAPSHOT FRONT END

Database:
  OpticalAdmin_FE_DailySnapshot_READY.accdb

This database preserves the exact linked-table paths from the uploaded zip:
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Ops\OpticalOps_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Reference\ReferenceConfig_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\WorkforceQuality\WorkforceQuality_BE.accdb

The current staged snapshot from the uploaded front end is included and marked Validated.

FIRST TEST
1. Copy OpticalAdmin_FE_DailySnapshot_READY.accdb into the Admin front-end folder on S:.
2. Keep the current front end as a backup; do not overwrite it yet.
3. Open the READY database. The Daily JobTracking Snapshot form opens automatically.
4. Use the four Open Staging buttons to confirm that the expected data is present.
5. Make sure nobody else has the back ends open.
6. Select Commit New or Changed Data.

DAILY USE
1. Select Import and Validate Snapshot.
2. Choose the JobTracking workbook containing CTM, InProcess, Tracking, and Shipping.
3. Review the staged tables.
4. Select Commit New or Changed Data.

SAFETY AND SIZE
- Every import replaces the four staged tables; snapshots do not accumulate.
- Commit uses indexed bulk queries and writes only new or matched records.
- Commit creates a dated OpticalOps backup under Backups\Ops before writing.
- The staged tables remain available after commit.
- Clear Staging is optional. If used, close the database afterward so Compact on Close can reclaim the space.
