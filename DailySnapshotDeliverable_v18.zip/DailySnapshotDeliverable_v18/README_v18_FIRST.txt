DAILY SNAPSHOT v18
==================

Open OpticalAdmin_FE_DailySnapshot_v18_READY.accdb.
The form title must say: Daily Snapshot Import - v18.

INSTALL AND FIRST RUN
---------------------
1. Close Access and retain your existing v17 file as a backup. Its local import
   history stays in that old file. This replacement starts with empty staging
   and import history; your existing back-end data is not included or replaced.
2. Extract the ZIP. Copy the v18 ACCDB beside the v17 front end in your normal
   approved working folder. Do not open it from inside the ZIP.
3. Open v18 using your normal approved Access workflow.
4. Save and close today's ORIGINAL complete Excel export. Do not add Note ID
   or change your normal column headings.
5. Select Import and Validate Daily Workbook, then select that Excel file.
6. Check that WorkLoad and Unsigned Notes both say Validated with plausible
   row counts. Review any Job Tracking result as usual.
7. Select Commit Validated Data. Review the ready domains, then confirm.
   If UnsignedNotes has zero rows, the confirmation explicitly warns that all
   currently listed notes will become no longer listed. Confirm only when the
   original complete report really has no unsigned notes.
8. Check the final commit results and Import History for successful commits
   and refreshed aggregate reporting data.
9. Repeat with the next day's complete export. Internal note IDs are stored in
   the Operations back end and remain available across front-end replacements.

The scrubbed sample provided for troubleshooting has blank Author and Patient
& Entry Date values. It intentionally cannot pass note-identity validation.
Use the original export on the approved workstation for the operational test.
Do not send patient-identifying data back for troubleshooting.

IF AN IMPORT FAILS
------------------
The results now retain the error number and description. Open Import History.
For row details, press F11, select All Access Objects, and open the local table
SnapshotDomainIssue. SourceKey identifies a source row (header is row 1).
Send the full error text and non-identifying issue messages if help is needed.
An unsuccessful WorkLoad or UnsignedNotes import blocks that domain's older
staged data from being committed. Correct the issue and import again.

BACK-END LINKS
--------------
All linked-table connection strings are preserved from the supplied v17 file.
The relevant destinations are:
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Ops\OpticalOps_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\WorkforceQuality\WorkforceQuality_BE.accdb
These spellings match v17; do not rename your folders to match this document.
If your deployed v17 was relinked to different paths, use Access's External
Data > Linked Table Manager to point v18 at the same back ends before commit.
The commit makes a dated back-end backup before writing. Same-second backups
receive distinct filenames. Unsigned-note writes use one transaction and an
exclusive Operations connection; close other applications using that back end
if Access reports that it is already in use.

NOTE TRACKING
-------------
No Note ID column is required in Excel. Access allocates internal IDs such as
DS18-1 in the Operations back end. Matching uses all four fields:
  Patient & Entry Date, Author, Note Title, Service.
Age of Note is excluded from matching. Changes to age update the same note.
Leading/trailing spaces and letter case are normalized for matching.
All four identifying values must be present and at most 255 characters each.
Age must be a nonnegative whole number of days.

Multiple rows with identical normalized identifying fields stop validation.
The importer does not merge those rows or assign arbitrary identities. Existing
ambiguous back-end records also stop commit before queue changes are saved.

This is exact-field matching, not a source-provided permanent note identifier.
If an identifying field changes, the record is treated as a new note and the
old unmatched record becomes no longer listed. Review such source corrections
before relying on new/disappeared counts. Two truly different notes that are
indistinguishable in the export cannot be reliably tracked separately.

An absent note becomes "no longer listed" after a successful complete snapshot.
This does not establish whether it was signed, deleted, or otherwise removed.
A reappearing note with the same identifying values reuses its ID and retains
its earlier disappearance observation. Same-day imports replace that day's
observations; daily history is retained across days.

Snapshot date is the import day. Import and commit the current day's original
complete report on the same day. Older staged snapshots cannot be committed,
and a snapshot cannot overwrite a queue with a later LastSeenDate.

The backend field names ResolvedDate and ResolvedCount remain for compatibility.
For this importer, they mean no longer listed, NOT confirmed signed. Aggregate
reporting tables keep their existing names. No patient identity is added to
aggregate reporting tables.

VERIFICATION
------------
Tested in Microsoft Access 16 using disposable back ends:
- Reproduced v17 error 3265; refreshing DAO table metadata fixes the import.
- Supplied WorkLoad sample: 9 rows validated, committed, and aggregates refreshed.
- Repeated WorkLoad commit: 0 new rows and 9 updated rows.
- Five-column synthetic note exports validate with no Note ID column.
- Same-day repeats and changing ages retain IDs without duplicate observations.
- Disappearance, reappearance, empty queues, and daily history work.
- Ambiguous matching fields and missing headers produce descriptive errors.
- Failed imports cannot commit previous stages; older snapshots are rejected.
- A forced second-row write failure rolls back earlier writes; retry succeeds.
- Packaged VBA compiles, runs, matches the tested source, and has no test hooks.

The real VA-network back ends and unscrubbed export were not available here.
Their operational validation is steps 4-8 above. No production data was changed
during these tests. Job Tracking's VBA module is unchanged from v17.
