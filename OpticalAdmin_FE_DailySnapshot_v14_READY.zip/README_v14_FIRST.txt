DAILY SNAPSHOT v14 — WORKLOAD AND UNSIGNED NOTES
=================================================

Open OpticalAdmin_FE_DailySnapshot_v14_READY.accdb and use the form:
    Daily Snapshot: Job Tracking, WorkLoad, and Unsigned Notes

One workbook can now be processed as three independent domains:
  1. Job Tracking: CTM, InProcess, Tracking, and Shipping
  2. WorkLoad
  3. UnsignedNotes

Use “Import and Validate Daily Workbook” to select the workbook once.  A bad
sheet does not replace any previously validated stage for that domain and does
not block the other two domains.  Review and commit each domain separately.
There is intentionally no all-or-nothing Commit button.

REQUIRED WORKBOOK HEADERS
-------------------------
WorkLoad must have these headers:
  Date
  StaffName                         (may be blank)
  Position - PositionTitle
  Service Section - ServiceSection
  Activity Specialty CPM Clinic Group - Clinic
  LocationName
  Activity Group - Activity
  Activity Count

UnsignedNotes must have these headers:
  Note ID                           (new, required, permanent source ID)
  Service
  Author
  Age of Note
  Patient & Entry Date
  Note Title

The supplied scrubbed DailyTracking.xlsm does not contain the new Note ID
column, so UnsignedNotes validation will deliberately fail until the real
export includes that exact header and a unique ID in every nonblank row.

WHAT IS WRITTEN
---------------
WorkLoad writes the new WorkforceQuality_BE.WorkloadActivity table.  It leaves
the old EmployeeWorkload table unchanged.  A normalized combination of date
and all activity dimensions identifies a row, so a changed activity count is
updated and rows absent from a later workbook are retained as history.

UnsignedNotes writes OpticalOps_BE.UnsignedNote (the current, restricted queue)
and UnsignedNoteObservation (daily history).  The current queue uses Note ID as
its key.  A same-day re-import updates that day's observation instead of adding
a duplicate.  Because the export is treated as a full queue, notes missing from
the next committed snapshot are marked resolved.

SECURITY AND REPORTING
----------------------
The “Open Restricted Queue” button is for the Admin Frontend only and displays
the Patient & Entry Date field.  The aggregate Unsigned Notes queries do not
contain that field.  Saved datasheet reporting queries support sorting and
filtering directly in Access:
  qryUnifiedWorkloadActivity
  qryWorkloadActivityByDay
  qryWorkloadActivityByMonth
  qryCurrentUnsignedNotesQueue        (restricted Admin queue)
  qryUnsignedNotesAging
  qryUnsignedNotesBacklogTrend

Unsigned Notes use the requested aging bands: 0–2 days, 3–6 days, and 7+ days.
After each successful WorkLoad or Unsigned Notes commit, the relevant aggregate
data is refreshed.  A refresh failure does not undo the source commit; use
“Retry Reports Refresh” after correcting the problem.

BACKUPS AND HISTORY
-------------------
Before a WorkLoad commit, a dated WorkforceQuality back-end backup is created.
Before an Unsigned Notes commit, a dated Operations back-end backup is created.
“Extension Import History” shows source filename, source/accepted row counts,
validation issue counts, commit status, refresh status, and notes.  Detailed
validation issues are in SnapshotDomainIssue.

Before replacing any production front end, make a normal copy and confirm that
this file's linked back-end paths match the environment where it will run.
