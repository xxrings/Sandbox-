DAILY SNAPSHOT v21 - REMOVE UNDATED WORKLOAD HISTORY AND REFRESH
=============================================================

Your date check returned:
  30,690 historical EmployeeWorkload records in total
  17,981 with blank dates
  12,709 with valid dates
       0 with invalid nonblank dates

You confirmed that the undated historical records do not need to be kept.
v21 provides a separate one-time cleanup for those records. No live database
has been changed while this release was built or tested.

WHAT TO DO
1. Close your old front end and keep it as a backup. Close other Access files
   using the Workforce Quality backend; the cleanup requires exclusive access.
2. Extract this ZIP. Place OpticalAdmin_FE_DailySnapshot_v21_READY.accdb beside
   the current front end in your working folder, then open it directly.
3. Confirm the form title is Daily Snapshot Import - v21.
4. Click Remove Undated History + Refresh.
5. The confirmation shows how many historical rows have blank dates. Expect
   17,981 unless that source table has changed since your check. Click Yes to
   remove them and rebuild the reports.
6. Expect WorkLoad cleanup and report refresh completed, followed by the actual
   removed count, remaining historical count, and the backup file location.
   With unchanged data, 12,709 dated historical records will remain.
7. Use v21 for future daily imports and commits as usual. You do not need to
   import or commit the already-saved workbook again for this repair.

EXACT CLEANUP SCOPE
The cleanup deletes only EmployeeWorkload records whose historical date is
Null. It supports WorkDate in the normalized schema and Date in the older
schema. It does not delete WorkloadActivity records from the daily importer,
dated historical records, Job Tracking records, or unsigned notes.

It creates a complete Workforce Quality backend backup first, then confirms
the backup is readable and its historical date counts/activity summary match
the source. Deletion and both daily/monthly report replacements run in one
transaction. If the report rebuild fails, the deletion and report replacements
roll back together. No dates are invented or filled in.

The backup is created under the existing database root's Backups\Workforce
folder, with a name beginning WorkforceQuality_BE_before_undated_cleanup.
Import History records the operation separately as Workload cleanup, with
status Cleaned and refreshed and the full backup path in Notes. Its import
source/accepted counts are zero because this operation is not a new import.

Repeating cleanup after success removes zero rows and rebuilds the reports.
Ordinary Import/Commit and Refresh WorkLoad Reports do not delete undated
history automatically. If undated history is later added, ordinary refresh
reports the dated records and explicitly warns about the excluded rows.
Malformed nonblank historical dates, and missing/invalid dates in daily
WorkloadActivity, still stop the refresh.

IF CLEANUP FAILS
Send the complete error message. A locked database, unreadable backup, or lack
of write permission to the backup folder can prevent cleanup. Do not manually
delete rows to work around an error. If you opened EmployeeWorkload in the same
Access session, close Access and reopen v21 directly before trying cleanup.

LINKS AND EXISTING DATA
v21 retains v20's supplied backend links, including:
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\WorkforceQuality\WorkforceQuality_BE.accdb
  S:\Operative Care\Eye-Supervisors\Data\OpticlshopDB\BackEnds\Ops\OpticalOps_BE.accdb
If your deployed front end uses different links, point v21 to the same existing
backends using External Data > Linked Table Manager. The ZIP contains no
replacement backends. Previous local import history stays in the old front end.
Existing note IDs and day-to-day note observations remain in the Ops backend.
Excel totals/footer handling and unsigned-note matching remain unchanged.

VERIFICATION
Native Access tests use disposable local databases. They cover date handling,
report totals, cleanup boundaries, backup contents, rollback on failure, repeat
operations, import acceptance counts, and the unsigned-note lifecycle.
See TEST_RESULTS_v21.txt for the completed checks. Your VA-network database
was not accessed during these tests.
