DAILY SNAPSHOT v17 — WORKLOAD IMPORT CORRECTION
================================================

Use OpticalAdmin_FE_DailySnapshot_v17_READY.accdb.

v17 corrects the WorkLoad date-header handler that could raise error 3265
(Item not found in this collection) before validation. It now resolves the
date field by reading the imported fields directly, without renaming any
spreadsheet columns.

Accepted WorkLoad date labels include Date, Work Date, Workload Date, Activity
Date, Report Date, Date of Service, and Access-imported Date1 variants.

UnsignedNotes will continue to fail until its export has the exact Note ID
header and a permanent unique value for every nonblank row.
